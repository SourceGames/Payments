# tutorial LINK #
[paypal payment gateway integration in codeigniter](http://webeasystep.com/blog/view_article/paypal_payment_gateway_integration_in_codeigniter)

# video LINK #
[paypal payment gateway integration in php source code](https://www.youtube.com/watch?v=Wx6W3_1LE5w)